import React from 'react';
import '../styles/Login.css';
export default function Login(){
  return (
    <div className="page login-page">
      <h2>Login</h2>
      <p>Simple placeholder. Implement real auth as needed.</p>
    </div>
  );
}
