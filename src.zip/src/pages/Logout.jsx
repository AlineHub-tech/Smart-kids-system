import React from 'react';
import '../styles/Logout.css';
export default function Logout(){
  return (
    <div className="page logout-page">
      <h2>Logout</h2>
      <p>You are logged out.</p>
    </div>
  );
}